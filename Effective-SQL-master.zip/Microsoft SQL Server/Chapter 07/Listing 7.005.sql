-- Listing 7.5 Enabling execution profiling in SQL Server

-- Displays results in a tabular form, but about to be deprecated. 
-- SET STATISTICS PROFILE ON;

-- Use this instead to get the results in XML.
SET STATISTICS XML ON;