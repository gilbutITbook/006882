CREATE DATABASE Item19Example;
GO

USE Item19Example;
GO

CREATE TABLE tblPostSales(
    Product varchar (255), 
    Jan money, 
    Feb money, 
    Mar money, 
    Apr money, 
    May money, 
    Jun money, 
    Jul money, 
    Aug money, 
    Sep money, 
    Oct money, 
    Nov money, 
    Dec money);  
